import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ParkingDemo extends JFrame implements ActionListener {

    private JComboBox<String> vehicleTypeComboBox;
    private JButton checkAvailabilityButton;

    public ParkingDemo() {
        setTitle("Parking Demo");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        JLabel vehicleTypeLabel = new JLabel("Vehicle Type:");
        panel.add(vehicleTypeLabel);

        String[] vehicleTypes = {"Car", "Bike", "Microbus", "Jeep"};
        vehicleTypeComboBox = new JComboBox<>(vehicleTypes);
        panel.add(vehicleTypeComboBox);

        checkAvailabilityButton = new JButton("Check Availability");
        checkAvailabilityButton.addActionListener(this);
        panel.add(checkAvailabilityButton);

        setContentPane(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == checkAvailabilityButton) {
            // Check if a parking slot is available
            boolean isParkingAvailable = checkParkingAvailability();

            // Show a pop-up message based on the availability status
            if (isParkingAvailable) {
                JOptionPane.showMessageDialog(this, "You can park your " + vehicleTypeComboBox.getSelectedItem() + " by visiting Park A Car. Thank you.");
            } else {
                JOptionPane.showMessageDialog(this, "Sorry, no parking slot is free right now. Wait for some time and try again. Thank you.");
            }
        }
    }

    private boolean checkParkingAvailability() {
        // Check the availability of parking slots
        // This is a dummy method that always returns false
        return false;
    }

    public static void main(String[] args) {
        new ParkingDemo();
    }
}
