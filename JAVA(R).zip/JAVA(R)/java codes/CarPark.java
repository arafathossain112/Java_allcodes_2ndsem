import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CarPark extends JFrame {

    private JTextField nameField;
    private JTextField modelField;
    private JTextField colourField;
    private JTextField numberPlateField;
    private JTextField contactNumberField;
    private JButton parkbutton;
    private JLabel statusLabel;

    private String[][] parkingSlots = new String[6][5]; 

    public CarPark() {
        
        super("Car Park");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 setLocationRelativeTo(null);
		 
		  

	
        nameField = new JTextField(30);
        modelField = new JTextField(30);
        colourField = new JTextField(30);
        numberPlateField = new JTextField(30);
        contactNumberField = new JTextField(30);

        JButton parkbutton = new JButton("Park");
		parkbutton.setBackground(Color.BLUE);
        statusLabel = new JLabel("Enter car details and click Park.");
		statusLabel.setForeground(Color.RED);

        JPanel panel = new JPanel();
		panel = new JPanel();
        panel.setBackground(Color.ORANGE);
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Model:"));
        panel.add(modelField);
        panel.add(new JLabel("Colour:"));
        panel.add(colourField);
        panel.add(new JLabel("Number Plate:"));
        panel.add(numberPlateField);
        panel.add(new JLabel("Contact Number:"));
        panel.add(contactNumberField);
        panel.add(parkbutton);
        panel.add(statusLabel);
        add(panel);

        parkbutton.addActionListener(e -> {
            String name = nameField.getText();
            String model = modelField.getText();
            String colour = colourField.getText();
            String numberPlate = numberPlateField.getText();
            String contactNumber = contactNumberField.getText();

            int slotNumber = findEmptySlot();
            if (slotNumber == -1) {
                statusLabel.setText("Sorry, car park is full.");
            } else {
                
                parkingSlots[slotNumber / 5][slotNumber % 5] = String.format("%s %s %s %s %s", name, model, colour, numberPlate, contactNumber);
                statusLabel.setText(String.format("Car parked in slot %d.", slotNumber));
            }
        });

        
        setVisible(true);
    }

    private int findEmptySlot() {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 5; j++) {
                if (parkingSlots[i][j] == null) {
                    return i * 5 + j; 
                }
            }
        }
        return -1; 
    }

    public static void main(String[] args) {
        new CarPark();
    }
}
