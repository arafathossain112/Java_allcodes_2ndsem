import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminDashboard extends JFrame implements ActionListener {
    
    JLabel locationLabel, emailLabel, phoneLabel, nameLabel, idLabel, adminEmailLabel;
    JTextField feedbackTextField;
    JButton submitButton;
    JTextArea messageTextArea;

    
    public AdminDashboard() {
        
        setTitle("Admin Dashboard");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

       
        locationLabel = new JLabel("Location: Kuratoli, Dhaka");
        emailLabel = new JLabel("Email: CineverseParking02@gmail.com");
        phoneLabel = new JLabel("Phone: 01867352137");
        nameLabel = new JLabel("Admin Name: ARAFAT HOSSAIN");
        idLabel = new JLabel("ID: 22-49039-3");
        adminEmailLabel = new JLabel("Email: arafathossainlihan2002@gmail.com");

        feedbackTextField = new JTextField();
        submitButton = new JButton("Submit");
		submitButton.setBackground(Color.GREEN);
        submitButton.addActionListener(this);

        messageTextArea = new JTextArea();
        messageTextArea.setEditable(false);
        messageTextArea.setLineWrap(true);

        
        JPanel panel = new JPanel();
		panel = new JPanel();
        panel.setBackground(Color.decode("#a6a6a6"));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(locationLabel);
        panel.add(emailLabel);
        panel.add(phoneLabel);
        panel.add(nameLabel);
        panel.add(idLabel);
        panel.add(adminEmailLabel);

        panel.add(Box.createVerticalStrut(20));

        panel.add(new JLabel("Feedback:"));
        panel.add(feedbackTextField);
        panel.add(submitButton);

        panel.add(Box.createVerticalStrut(20));


        
        add(panel);
    }

    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            String feedback = feedbackTextField.getText();
            
            feedbackTextField.setText("");
            messageTextArea.setText("Thank you for your feedback!");
        }
    }

    public static void main(String[] args) {
        AdminDashboard dashboard = new AdminDashboard();
        dashboard.setVisible(true);
    }
}