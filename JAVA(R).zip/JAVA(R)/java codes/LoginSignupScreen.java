import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginSignupScreen extends JFrame implements ActionListener {

    private JLabel nameLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JLabel addressLabel;
    private JLabel passwordLabel;
    private JTextField nameTextField;
    private JTextField emailTextField;
    private JTextField phoneTextField;
    private JTextField addressTextField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton signupButton;
    private JPanel panel;

    public LoginSignupScreen() {
        setTitle("Car Parking System Login/Sign-up");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        
        // Create UI components
        nameLabel = new JLabel("Name:");
        emailLabel = new JLabel("Email:");
        phoneLabel = new JLabel("Phone:");
        addressLabel = new JLabel("Address:");
        passwordLabel = new JLabel("Password:");
        nameTextField = new JTextField(20);
        emailTextField = new JTextField(20);
        phoneTextField = new JTextField(20);
        addressTextField = new JTextField(20);
        passwordField = new JPasswordField(20);
        loginButton = new JButton("Login");
        signupButton = new JButton("Sign-up");
        loginButton.addActionListener(this);
        signupButton.addActionListener(this);
        panel = new JPanel(new GridLayout(6, 2));
        
        // Add components to panel
        panel.add(nameLabel);
        panel.add(nameTextField);
        panel.add(emailLabel);
        panel.add(emailTextField);
        panel.add(phoneLabel);
        panel.add(phoneTextField);
        panel.add(addressLabel);
        panel.add(addressTextField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(signupButton);
        
        // Add panel to frame
        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Perform login or sign-up verification
        if (e.getSource() == loginButton) {
            String email = emailTextField.getText();
            String password = new String(passwordField.getPassword());
            if (verifyLogin(email, password)) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                // Redirect to main menu or parking status screen
            } else {
                JOptionPane.showMessageDialog(this, "Invalid email or password.");
            }
        } else if (e.getSource() == signupButton) {
            String name = nameTextField.getText();
            String email = emailTextField.getText();
            String phone = phoneTextField.getText();
            String address = addressTextField.getText();
            String password = new String(passwordField.getPassword());
            if (verifySignup(name, email, phone, address, password)) {
                JOptionPane.showMessageDialog(this, "Sign-up successful!");
                // Redirect to main menu or parking status screen
            } else {
                JOptionPane.showMessageDialog(this, "Sign-up failed. Please check your details and try again.");
            }
        }
    }

    private boolean verifyLogin(String email, String password) {
        // Check if email and password match an existing user in the database
        // Return true if login is successful, false otherwise
}}

    private boolean verifySignup(String name, String email, String phone, String address, String password) {
        // Check if email already exists in the database
        // If not, add the new user to the database and return true
        // If email already exists, return false
    }}

    public static void main(String[] args) {
        new LoginSignupScreen();
    }
}
