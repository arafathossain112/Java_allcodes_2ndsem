import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RemoveCar extends JFrame implements ActionListener {

    private JTextField carName, carModel, carPlate, parkingSlot;
    private JButton removeButton;

    public RemoveCar() {
        setTitle("Remove Car");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		  ImageIcon imageIcon = new ImageIcon("IMAGE.JPEG");
		Image image = imageIcon.getImage();
		setContentPane(new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
		}});

        JPanel panel = new JPanel();
		 panel.setBackground(Color.ORANGE);
        panel.setLayout(new GridLayout(5, 2));

        JLabel nameLabel = new JLabel("Car Name:");
        carName = new JTextField(20);
        JLabel modelLabel = new JLabel("Car Model:");
        carModel = new JTextField(20);
        JLabel plateLabel = new JLabel("Car Number Plate:");
        carPlate = new JTextField(20);
        JLabel slotLabel = new JLabel("Parking Slot:");
        parkingSlot = new JTextField(20);

        panel.add(nameLabel);
        panel.add(carName);
        panel.add(modelLabel);
        panel.add(carModel);
        panel.add(plateLabel);
        panel.add(carPlate);
        panel.add(slotLabel);
        panel.add(parkingSlot);

        removeButton = new JButton("Remove");
		removeButton.setBackground(Color.RED);
        removeButton.addActionListener(this);

        panel.add(removeButton);

        add(panel);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == removeButton) {
            int option = JOptionPane.showConfirmDialog(this, "Are you sure to remove your car?");
            if (option == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this, "Your car has been removed.");
            }
        }
    }

    public static void main(String[] args) {
        new RemoveCar();
    }
}
