import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainMenu extends JFrame implements ActionListener {

    private JButton parkbutton;
    private JButton removebutton;
    private JButton availabilitybutton;
    private JButton adminbutton;
    private JPanel panel;

    public MainMenu() {
        setTitle("Car Parking System Main Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 400);

        ImageIcon imageIcon = new ImageIcon("IMAGE.JPEG");
        Image image = imageIcon.getImage();
        setContentPane(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        });

        parkbutton = new JButton("Park A Car");
        parkbutton.setBackground(Color.GREEN);
        removebutton = new JButton("Remove a car");
        removebutton.setBackground(Color.RED);
        availabilitybutton = new JButton("Check availability");
        availabilitybutton.setBackground(Color.YELLOW);

        adminbutton = new JButton("Admin Dashboard");
        parkbutton.addActionListener(this);
        removebutton.addActionListener(this);
        availabilitybutton.addActionListener(this);
        adminbutton.addActionListener(this);
        panel = new JPanel(new GridLayout(2, 2));
        panel.setBackground(Color.BLACK);

        panel.add(parkbutton);
        panel.add(removebutton);
        panel.add(availabilitybutton);
        panel.add(adminbutton);

        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == parkbutton) {
            CarPark carPark = new CarPark();
            carPark.setVisible(true);
        } else if (e.getSource() == removebutton) {
            RemoveCar removeCar= new RemoveCar();
			removeCar.setVisible(true);
        } else if (e.getSource() == availabilitybutton) {
            
        } else if (e.getSource() == adminbutton) {
            AdminDashboard adminDashboard = new AdminDashboard();
			adminDashboard.setVisible(true);
        }
    }

    public static void main(String[] args) {
        new MainMenu();
    }
}
