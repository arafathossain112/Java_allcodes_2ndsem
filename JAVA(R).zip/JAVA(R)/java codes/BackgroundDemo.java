import javax.swing.*;
import java.awt.*;

public class BackgroundDemo extends JFrame {

    private JPanel panel;

    public BackgroundDemo() {
        setTitle("Background Demo");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon imageIcon = new ImageIcon("IMAGE.JPEG"); // Replace with the path to your image file
                Image image = imageIcon.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        
        panel.setLayout(new BorderLayout());

        // Add other components to the panel here

        setContentPane(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        new BackgroundDemo();
    }
}
