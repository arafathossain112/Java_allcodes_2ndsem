import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import javax.imageio.*;

public class LoginScreen extends JFrame implements ActionListener {

    private JLabel userLabel;
    private JLabel passwordLabel;
    private JTextField userTextField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JPanel panel;

    public LoginScreen() {
        setTitle("Car Parking System Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 400);
		ImageIcon ImageIcon=new ImageIcon("M.png");
		Image Image = ImageIcon.getImage();
		
		JLabel Background;
		ImageIcon img = new ImageIcon("M.png");
		Background = new JLabel("",img,JLabel.CENTER);
		Background.setBounds(0,0,1106,595);
        
        
        userLabel = new JLabel("Username:");
        passwordLabel = new JLabel("Password:");
        userTextField = new JTextField(20);
        passwordField = new JPasswordField(20);
        loginButton = new JButton("Login");
        loginButton.addActionListener(this);
        panel = new JPanel(new GridLayout(3, 2));
        
        
        panel.add(userLabel);
        panel.add(userTextField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);
		panel.add(Background);
        
        
        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        String username = userTextField.getText();
        String password = new String(passwordField.getPassword());
        if (username.equals("topark") && password.equals("password")) {
            JOptionPane.showMessageDialog(this, "Login successful!");
            
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.");
        }
    }

    public static void main(String[] args) {
        new LoginScreen();
    }
}