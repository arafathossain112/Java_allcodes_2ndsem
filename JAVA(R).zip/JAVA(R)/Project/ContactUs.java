import javax.swing.*;    
import java.awt.event.*; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener; 
import java.awt.*;
import javax.swing.ImageIcon;
import javax.imageio.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;


public class ContactUs extends JFrame implements ActionListener  {
    
	JButton b;
	JFrame f;

    ContactUs() {    
    f=new JFrame("Contact Us");

	 
     JLabel l1=new JLabel("Write your Email: ");    
     l1.setBounds(20,20,180,30); 
	   
	 
     b = new JButton("Send");  
     b.setBounds(100,280, 80,30);
     b.addActionListener(this);	
	 
	 
     final JTextField text = new JTextField();  
     text.setBounds(100,120, 100,30); 
	 
	ImageIcon ImageIcon = new ImageIcon("L1.png");
    Image Image = ImageIcon.getImage();
    f.setIconImage(Image);
	
	JLabel Background;
	ImageIcon img = new ImageIcon("L1.png");
	Background = new JLabel ("",img,JLabel.CENTER);
	Background.setBounds(0,0,300,600);
		
 
	f.add(l1);  
	f.add(b); 
	f.add(text);
    f.add(Background);	

	
    f.setSize(300,600);    
    f.setLayout(null);
    f.setLocationRelativeTo(null);     
    f.setVisible(true);
	f.setDefaultCloseOperation(EXIT_ON_CLOSE);
   
}

	public void actionPerformed(ActionEvent e) {
        if(e.getSource() == b)
		{
          String to = "xxx";
          String from = "xxxxx";
          String host = "localhost";
          Properties properties = System.getProperties();
          properties.setProperty("mail.smtp.host", host);
          Session session = Session.getDefaultInstance(properties);
		  
		  try {
         MimeMessage message = new MimeMessage(session);
         message.setFrom(new InternetAddress(from));
         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
         message.setSubject("This is the Subject Line!");
         message.setText("This is actual message");
         Transport.send(message);
         JOptionPane.showMessageDialog(null, "Email Sent!");
      } catch (MessagingException mex) {
         mex.printStackTrace();
      }
			
			
	}
		
    }  
}