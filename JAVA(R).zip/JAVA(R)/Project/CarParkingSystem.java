import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CarParkingSystem extends JFrame {

    private static final int NUM_SPOTS = 10;
    private JLabel[] parkingSpots;
    private JButton parkCarButton;
    private JButton removeCarButton;

    public CarParkingSystem() {
        super("Car Parking System");
        setSize(400, 400);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel parkingPanel = new JPanel(new GridLayout(NUM_SPOTS, 1));
        parkingSpots = new JLabel[NUM_SPOTS];
        for (int i = 0; i < NUM_SPOTS; i++) {
            parkingSpots[i] = new JLabel("Spot " + (i+1), JLabel.CENTER);
            parkingSpots[i].setOpaque(true);
            parkingSpots[i].setBackground(Color.GREEN);
            parkingPanel.add(parkingSpots[i]);
        }
        add(parkingPanel, BorderLayout.CENTER);

        parkCarButton = new JButton("Park Car");
        parkCarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String plateNumber = JOptionPane.showInputDialog("Enter license plate number:");
                if (plateNumber != null && !plateNumber.isEmpty()) {
                    boolean parked = false;
                    for (int i = 0; i < NUM_SPOTS; i++) {
                        if (parkingSpots[i].getBackground() == Color.GREEN) {
                            parkingSpots[i].setBackground(Color.RED);
                            parkingSpots[i].setText(plateNumber);
                            parked = true;
                            break;
                        }
                    }
                    if (!parked) {
                        JOptionPane.showMessageDialog(null, "All parking spots are full.");
                    }
                }
            }
        });
        add(parkCarButton, BorderLayout.NORTH);

        removeCarButton = new JButton("Remove Car");
        removeCarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String plateNumber = JOptionPane.showInputDialog("Enter license plate number:");
                if (plateNumber != null && !plateNumber.isEmpty()) {
                    boolean removed = false;
                    for (int i = 0; i < NUM_SPOTS; i++) {
                        if (parkingSpots[i].getBackground() == Color.RED && parkingSpots[i].getText().equals(plateNumber)) {
                            parkingSpots[i].setBackground(Color.GREEN);
                            parkingSpots[i].setText("Spot " + (i+1));
                            removed = true;
                            break;
                        }
                    }
                    if (!removed) {
                        JOptionPane.showMessageDialog(null, "Car with license plate number " + plateNumber + " is not parked.");
                    }
                }
