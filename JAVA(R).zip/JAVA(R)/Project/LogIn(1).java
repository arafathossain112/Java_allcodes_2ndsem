import javax.swing.*;    
import java.awt.event.*; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener; 
import java.awt.*;
import javax.swing.ImageIcon;
import javax.imageio.*;


public class LogIn extends JFrame implements ActionListener  {
    
	JButton b,b1;
	JFrame f;

    LogIn() {    
    f=new JFrame("LogIn Screen");
    
     final JLabel label = new JLabel(); 
	 label.setBounds(20,150, 200,50); 
	 
     final JPasswordField value = new JPasswordField();   
     value.setBounds(100,75,100,30); 
	 
     JLabel l1=new JLabel("Username:");    
     l1.setBounds(20,20,80,30); 
	 
     JLabel l2=new JLabel("Password:");    
     l2.setBounds(20,75, 80,30);   
	 
     b = new JButton("Login");  
     b.setBounds(100,280, 80,30);
     b.addActionListener(this);	

     b1 = new JButton("SignUp");  
     b1.setBounds(100,480, 80,30);
     b1.addActionListener(this);	 
	 
     final JTextField text = new JTextField();  
     text.setBounds(100,20, 100,30); 
	 
	ImageIcon ImageIcon = new ImageIcon("L1.png");
    Image Image = ImageIcon.getImage();
    f.setIconImage(Image);
	
	JLabel Background;
	ImageIcon img = new ImageIcon("L1.png");
	Background = new JLabel ("",img,JLabel.CENTER);
	Background.setBounds(0,0,300,600);
		
    f.add(value); 
	f.add(l1); 
	f.add(label); 
	f.add(l2); 
	f.add(b); 
	f.add(b1);
	f.add(text);
    f.add(Background);	

	
    f.setSize(300,600);    
    f.setLayout(null);
    f.setLocationRelativeTo(null);     
    f.setVisible(true);
	f.setDefaultCloseOperation(EXIT_ON_CLOSE);
   
}

	public void actionPerformed(ActionEvent e) {
        if(e.getSource() == b)
		{
			JOptionPane.showMessageDialog(null, "You have clicked login button ");
			f.setVisible(false);
			new ContactUs();
			
		}
		else if (e.getSource() == b1)
		{
			JOptionPane.showMessageDialog(null, "You have clicked Signup button ");
		}
    }  
}