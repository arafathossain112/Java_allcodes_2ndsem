import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import java.awt.event.ActionEvent;

public class CarParkingSystemGUI extends JFrame
 //implements ActionListener 
 {

    private JButton parkButton, removeButton, viewButton;
    private JTextField ownerNameField, modelField, phoneNumberField, plateNumberField, carColorField;
    private JTextArea statusArea;
    private int availableSlots;

    public CarParkingSystemGUI() {
        // Set the window properties
        setTitle("Car Parking System");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Create the input fields
        ownerNameField = new JTextField();
        modelField = new JTextField();
        phoneNumberField = new JTextField();
        plateNumberField = new JTextField();
        carColorField = new JTextField();

        // Create the buttons
        parkButton = new JButton("Park Your Car");
      //  parkButton.addActionListener(this);
        removeButton = new JButton("Remove Your Car");
      //  removeButton.addActionListener(this);
        viewButton = new JButton("View Remaining Parking Slot");
     //   viewButton.addActionListener(this);

        // Create the status area
        statusArea = new JTextArea();
        statusArea.setEditable(false);

        // Add the components to the content pane
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        // Create the park panel
        JPanel parkPanel = new JPanel(new GridLayout(6, 2));
        parkPanel.setBorder(BorderFactory.createTitledBorder("Park Your Car"));
        parkPanel.add(new JLabel("Owner Name:"));
        parkPanel.add(ownerNameField);
        parkPanel.add(new JLabel("Car Model:"));
        parkPanel.add(modelField);
        parkPanel.add(new JLabel("Phone Number:"));
        parkPanel.add(phoneNumberField);
        parkPanel.add(new JLabel("Car Number Plate:"));
        parkPanel.add(plateNumberField);
        parkPanel.add(new JLabel("Car Colour:"));
        parkPanel.add(carColorField);
        parkPanel.add(new JLabel(""));
        parkPanel.add(parkButton);

        // Create the remove panel
        JPanel removePanel = new JPanel(new GridLayout(3, 2));
        removePanel.setBorder(BorderFactory.createTitledBorder("Remove Your Car"));
        removePanel.add(new JLabel("Owner Name:"));
        JTextField removeOwnerNameField = new JTextField();
        removePanel.add(removeOwnerNameField);
        removePanel.add(new JLabel("Car Number Plate:"));
        JTextField removePlateNumberField = new JTextField();
        removePanel.add(removePlateNumberField);
        JButton removeSubmitButton = new JButton("Submit");
	}
      //  removeSubmitButton.addActionListener new ActionListener() {
           // public void actionPerformed(ActionEvent e) {
                //if (removeOwnerNameField.getText().equals(ownerNameField.getText()) && removePlateNumberField.getText().equals(plateNumberField.getText())) {
                    //dispose();
                   // statusArea.setText("Your car has been removed. Remaining slots: " + ++availableSlots);
                   // JOptionPane.showMessageDialog(null, "Your car has been removed.", "Success", JOptionPane.INFORMATION_MESSAGE);
               // } else {
                  //  JOptionPane.showMessageDialog(null, "Invalid owner name or car number plate.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            //}
        //}
        
