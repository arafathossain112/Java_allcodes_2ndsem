public static void main(String[] args) {
        CarParkingSystemGUI gui = new CarParkingSystemGUI();
        gui.setVisible(true);
    }    
