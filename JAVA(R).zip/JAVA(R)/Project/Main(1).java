public class Main{
	
	public static void main(String []ars)
	{
		new LogIn();
	}  
}    
