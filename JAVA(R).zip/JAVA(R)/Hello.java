public class Hello
{
public static void main(String [ ]args)
{
System.out.println("Helllo World");
System.out.println("Welcome To JAVA Class");
System.out.println("tumi fail");
System.out.println("porte bosho");
System.out.println("muri khaw");
}
}