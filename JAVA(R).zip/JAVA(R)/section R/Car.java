public class Car
{
	private String make;
	private String model;
	private int year;
	
	public Car(String make,model,int age)
	{
		this.make=make;
		this.model=model;
		this.year=year;
	}
	
	public Car(){}
	
	public void set_value(String make,model,int age)
	{
		this.make=make;
		this.model=model;
		this.year=year;
	}
	
	public void get_values()
	{
		System.out.println(make+model+year);
	}
}