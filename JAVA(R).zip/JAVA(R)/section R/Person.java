public class Person
{
	private String name;
	private int age;
	
	public Person (String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	
	public Person(){}
	
	public void set_value(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	
	public void get_value()
	{
		System.out.println(name+": "+age);
	}
}
