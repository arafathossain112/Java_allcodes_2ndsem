public class Main{
public static void main(String []args)
{
Circle C=new Circle();
C.set(15);
C.get();
}

}