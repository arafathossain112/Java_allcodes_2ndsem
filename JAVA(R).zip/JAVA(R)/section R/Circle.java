public class Circle
{
	
private double r;
Circle(){}
public set(double r)
{
	this.r=r;
} 
public get(){
System out.println("Area : "+Math.PI*r*r);
System out.prientln("Circumference : "+Math.PI*2*r*r);
}
}